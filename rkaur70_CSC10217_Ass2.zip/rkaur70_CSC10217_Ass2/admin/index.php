<?php
/*-------------------------------------------------------------------------------------------------
@Module: bv_caryard_admin_index.php
This server-side module provides main UI for the application (admin part)

@Author: Vinh Bui (vinh.bui@scu.edu.au)
@Modified by: 
@Date: 09/09/2017
-------------------------------------------------------------------------------------------------*/
require_once('main.php');
?>

<html>
<head>
<!--	<link rel="stylesheet" type="text/css" href="css/admin.css">
	<link rel="stylesheet" type="text/css" href="css/form.css">-->
    
    <link rel="stylesheet" type="text/css" href="css/admin_template_styles.css">
	<link rel="stylesheet" type="text/css" href="css/form_styles.css">
	<link rel="stylesheet" type="text/css" href="css/form.css">

    
	<script src="js/ajax.js"></script>
	<script src="js/admin.js"></script>
	<script src="js/new_member_validate.js"></script>

</head>

<body>
<div id="id_container">
	<header>
		<h1>ADMIN</h1>
        <h2>
        <?php 
            if(isset($_SESSION['member_authorised']))
            {
                echo "(Logged on as Member: ".$_SESSION['member_authorised'].")";
            }
            
            if(isset($_SESSION['authorised']))
            {                    
                echo "(Logged on as Administrator: ".$_SESSION['authorised'].")";
            }
        ?>
        </h2>
        <?php include_once('html/h_navbar.html'); ?>
	</header>
	<!-- left navigation area -->
	<div id="id_left">
		<!-- load the navigation panel by embedding php code -->
		<?php $controller->handleLoadLeftMoviezoneNavbarRequest()?>
	</div>
	<!-- right area -->	
	<div id="id_right">
		<!-- top navigation area -->
		<div id="id_topnav">			
			<!-- the top navigation panel is loaded on demand using Ajax (see js code) -->
		</div>
		<div id="id_content"></div>
	</div>
	<!-- footer area -->
</div>
</body>
</html>