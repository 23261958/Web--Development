<?php
/*-------------------------------------------------------------------------------------------------
@Module: model.php

@Author: 
@Date: 
--------------------------------------------------------------------------------------------------*/
require_once('config.php');

class Model {
    private $error;
    private $dbAdapter;
    
    // Add initialization code here
    public function __construct(){
        $this->dbAdapter = new DBAdapter(DB_CONNECTION_STRING, DB_USER, DB_PASS);
    }
    
    // Add code to free any unused resource    
    public function __destruct(){
        $this->dbAdapter->dbClose();
    }
    
    //Returns last error
    public function getError(){
        return $this->error;
    }
    
    //Authenticates the user.       
    public function adminLogin($user){
        //for now we simply accept anyone with webdev2 password
        if ($user['password'] == 'webdev2') 
        {
            $this->error = ERR_SUCCESS;            
            return true;
        } 
        else 
        {
            $this->error = ERR_AUTHENTICATION;
            return false;
        }
    }
    public function getNewReleaseMovies(){
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->getNewReleaseMovies();
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
            if(empty($this->error))
            {
                print("<br><br><br>");
                print("<h2>".ERR_NO_MOVIES."</h2>");
            }
        
        }
        return $result;        
    }
    public function getallMovies(){
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->getAllMovies();
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
            if(empty($this->error))
            {
                print("<br><br><br>");
                print("<h2>".ERR_NO_MOVIES."</h2>");
            }
        
        }
        return $result;        
    }
    public function getRandomNewReleases()
{
    $this->error = null; //reset the error first
    $this->dbAdapter->dbOpen();
    $result = $this->dbAdapter->get_two_random_new_releases();
    $this->dbAdapter->dbClose();
    if ($result == null)
    {
        $this->error = $this->dbAdapter->lastError();
        if(empty($this->error))
        {
            print("<br><br><br>");
            print("<h2>".ERR_NO_MOVIES." newRelease ".$condition['new_release_name']."</h2>");
        }
    }
    return $result;        

}
    //Returns the list of movies
    public function selectAllMovies(){
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->get_movies();
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
        }
        return $result;        
    }
    
    //Returns the selected movie
    public function selectedMovie($condition) {
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->get_selected_movie($condition);
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
        }
        return $result;        
    }
    
    //Returns the list of actors
    public function selectAllActors(){
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->get_actors();
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
        }
        return $result;        
    }
     //Returns the list of genres
     public function selectAllGenres(){
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->get_genres();
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
        }
        return $result;        
    }
    //Returns the selected actor
    public function selectedActor($condition) {
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->get_selected_actor_movies($condition);
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
            if(empty($this->error))
            {
                print("<br><br><br>");
                print("<h2>".ERR_NO_MOVIES." actor ".$condition['actor_name']."</h2>");
            }
        }

        return $result;        
    }
     //Returns the selected genre
     public function selectedGenre($condition) {
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->get_selected_genre_movies($condition);
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
            if(empty($this->error))
            {
                print("<br><br><br>");
                print("<h2>".ERR_NO_MOVIES." genre ".$condition['genre_name']."</h2>");
            }
        }

        return $result;        
    }
    //Returns the list of director
    public function selectAllDirectors(){
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->get_directors();
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
        }
        return $result;        
    }
    //Returns the selected director
    public function selectedDirector($condition) {
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->get_selected_director_movies($condition);
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
            if(empty($this->error))
            {
                print("<br><br><br>");
                print("<h2>".ERR_NO_MOVIES." director ".$condition['director_name']."</h2>");
            }
        }
        return $result;        
     
    }
    public function selectAllStudios(){
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->get_studios();
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
        }
        return $result;        
    }
    public function selectedStudio($condition) {
        $this->error = null; //reset the error first
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->get_selected_studio_movies($condition);
        $this->dbAdapter->dbClose();
        if ($result == null)
        {
            $this->error = $this->dbAdapter->lastError();
            if(empty($this->error))
            {
                print("<br><br><br>");
                print("<h2>".ERR_NO_MOVIES." studio ".$condition['studio_name']."</h2>");
            }
        }
        return $result;        
     
    }
//Returns the list of classification
public function selectAllClassifications(){
    $this->error = null; //reset the error first
    $this->dbAdapter->dbOpen();
    $result = $this->dbAdapter->get_classifications();
    $this->dbAdapter->dbClose();
    if ($result == null)
    {
        $this->error = $this->dbAdapter->lastError();
    }
    return $result;        
}
//Returns the selected classification
public function selectedClassification($condition) {
    $this->error = null; //reset the error first
    $this->dbAdapter->dbOpen();
    $result = $this->dbAdapter->get_selected_classification_movies($condition);
    $this->dbAdapter->dbClose();
    if ($result == null)
    {
        $this->error = $this->dbAdapter->lastError();
        if(empty($this->error))
        {
            print("<br><br><br>");
            print("<h2>".ERR_NO_MOVIES." classification ".$condition['classification']."</h2>");
        }
    }
    return $result;        


    }
    /* Add a new member
    */
    public function addMemberModel($member)
    {
        $this->dbAdapter->dbOpen();
        $result = $this->dbAdapter->memberAddDB($member);
        $this->dbAdapter->dbClose();
        $this->error = $this->dbAdapter->lastError();		
        return $result;	
    }
    
    //Authenticates the member.       
    function processMemberLoginRequest($usersEnteredName,$usersEnteredPassword) {
        global $dbError;
        $this->dbAdapter->dbOpen();	
        //userSelect returns null if NO matched user.
        $result = $this->dbAdapter->userSelect($usersEnteredName);
        $this->dbAdapter->dbClose();
        
        if ($result != null) 
        {
            if($usersEnteredPassword === $result[0]['password'])
            {
                $_SESSION['username'] = $usersEnteredName;
                $_SESSION['member_authorised'] = $usersEnteredName;
                $this->error = ERR_SUCCESS; 
                return true;
            } 
            else
            {
                //echo ("This is the message to the user wrong details");
                $this->error = ERR_AUTHENTICATION;
                return false;
            }
        }
        $error = $dbError;
    }
    
}
?>