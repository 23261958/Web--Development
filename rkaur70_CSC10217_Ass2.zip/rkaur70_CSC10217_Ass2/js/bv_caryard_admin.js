/*Use onload event to load the page with random cars
*/
// var editing_mode; //if we are in editing mode e.g. add/edit car

// window.addEventListener("load", function() {
// 	makeAjaxGetRequest('bv_caryard_admin_main.php','cmd_car_select_all', null, updateContent);
//     //show the top navigation panel
// 	makeAjaxGetRequest('bv_caryard_admin_main.php', 'cmd_show_top_nav', null, updateTopNav);
// 	editing_mode = false; //default when loaded
// });

/*Updates the content area if success
*/
function updateContent(data) {
	document.getElementById('id_content').innerHTML = data;
}



/*Handles onclick events to filter/add/edit/delete cars
*/

//validate submitted data
// function validate(movieform) {
// 	//regex
// 	var regex = [
// 		/^[A-Z][\w\s]{9,50}$/, //title
// 		/^[A-Z][a-z]{4,20}$/, //make
// 		/^[A-Z][\w\s]{2,20}$/, //body
// 		/^\d{4}$/, //year
// 		/^\d{1,6}$/, //odometer
// 		/[+-]?([0-9]*[.])?[0-9]+$/ //price
// 	];
// 	//error messages
// 	var errors = [
// 		'title begins with Capital letter and between 10-50 characters',
// 		'make begins with Capital letter and between 5-20 characters',
// 		'body begins with Capital letter and between 5-20 characters',
// 		'year should have 4 digits',
// 		'odometer should be between 0 - 999999',
// 		'price should be between 0 - 999999'
// 	];
// 	var names = [
// 		'title', 'make', 'body', 'year', 'odometer', 'price'
// 	];
// 	//perform the validation
// 	for (var i = 0; i < names.length; i++) {
// 		if (!regex[i].test(movieform.elements[names[i]].value)) {
// 			alert (errors[i]);
// 			return false;
// 		}
// 	}
// 	return true;
// }

//submit car data to server
function btnAddEditMovieSubmitClick(command) {
	if (!validate(document.movie))
		return;
	var moviedata = new FormData(document.movie);
	makeAjaxPostRequest('admin_main.php', command, data, function(data) {
		if (data == '_OK_') {
			if (command == 'cmd_movie_add') {
				alert('The car data has been successfully updated to the database');
				document.movie.reset(); //reset form
				document.getElementById('id_error').innerHTML = '';
			} else {
				btnAddEditMovieExitClick();
			}
		} else {
			document.getElementById('id_error').innerHTML = data;
		}
	});
}

//exit add/edit mode and return to browsing mode
function btnAddEditMovieExitClick() {
	makeAjaxGetRequest('admin_main.php', null, function(data) {
		updateContent(data);
		//show the top navigation panel
		makeAjaxGetRequest('admin_main.php', 'cmd_show_top_nav', null, function(data) {
			updateTopNav(data);
			editing_mode = false;
		});
	});	
}


//shows car add/edit form
function addMovieClick() {
	if (!editing_mode) {
		makeAjaxGetRequest('admin_main.php','cmd_movie_add_form', null, function(data) {		
			updateTopNav(); //reset and hide the search box	
			updateContent(data); //load the add/edit form to the content area
			updateMovieForm(); //populate the add/edit form
			editing_mode = true;
		});		
	}
}

//sends request to server to 
function editMovieClick(movie_id) {
	var params = '&movie_id=' + movie_id;
	makeAjaxGetRequest('admin_main.php','cmd_movie_edit_form', params, function(data) {		
		updateTopNav(); //reset and hide the search box	
		updateContent(data); //load the add/edit form to the content area		
		updateMovieForm(movie_id); //populate the add/edit form 
		editing_mode = true;		
	});
}

//sends request to server to display delete car UI
function deleteMovieClick() {
	if (!editing_mode) {
		if (confirm("Are you sure to delete selected cars?") == true) {
			makeAjaxGetRequest('admin_main.php','cmd_car_delete', null, function(data){
				if (data == '_OK_') {
					makeAjaxGetRequest('admin_main.php', null, updateContent);
				} else {
					updateContent(data);
				}
			});
		}
	}
}

//exit to the main app
function exitClick() {
	if (editing_mode)
		if (confirm("Data is not saved. Are you sure to exit?") == false)
			return;	
	//load the navigation panel on demand
	makeAjaxGetRequest('admin_main.php','cmd_admin_logout', null, function(data) {
		if (data == '_OK_') {
			editing_mode = false;
			window.location.replace('../index.php');
		}		
	});	
}

//handles the car checkbox click event to sends request to server to check/uncheck car
function movieCheckClick(check) {		
	var params = '&movie_id=' + check.value;
	makeAjaxGetRequest('admin_main.php','cmd_movie_check', params, function(data) {
		if (data == '_OK_') {		
			check.checked = true;
		} else
			check.checked = false;
	});
	event.stopPropagation(); //so edit event does not fire.
}


/*Gets the state list from server and create the options on the fly
*/
function updateMovieForm(movie_id) {
	//add car mode	
			if (movie_id != null) { //update car mode
				//update the form with car data
				var params = '&movie_id=' + movie_id;
				makeAjaxGetRequest('admin_main.php', 'cmd_movie_select_by_id', params, 
				function(data) {
					var moviedata = JSON.parse(data);
					document.movie.title.value = moviedata[0].title;
					document.movie.year.value = moviedata[0].year;
					document.movie.tagline.value = moviedata[0].tagline;
					document.movie.plot.value = moviedata[0].plot;
					document.movie.director_name.value = moviedata[0].director_name;
					document.movie.studio_name.value = moviedata[0].studio_name;
					document.movie.genre_name.value = moviedata[0].genre_name;
					document.movie.star1.value = moviedata[0].star1;	
					document.movie.star2.value = moviedata[0].star2;				
					document.movie.star3.value = moviedata[0].star3;				
					document.movie.costar1.value = moviedata[0].costar1;				
					document.movie.costar2.value = moviedata[0].costar2;				
					document.movie.costar3.value = moviedata[0].costar3;		
					document.movie.costar3.value = moviedata[0].costar3;				
					document.movie.rental_period.value = moviedata[0].rental_period;				
					document.movie.DVD_rental_price.value = moviedata[0].DVD_rental_price;				
					document.movie.DVD_purchase_price.value = moviedata[0].DVD_purchase_price;	
					document.movie.numDVD.value = moviedata[0].numDVD;				
					document.movie.numDVDout.value = moviedata[0].numDVDout;				
					document.movie.numDVDout.value = moviedata[0].numDVDout;				
					document.movie.BlueRay_rental_price.value = moviedata[0].BlueRay_rental_price;				
					document.movie.BluRay_purchase_price.value = moviedata[0].BluRay_purchase_price;			
					document.movie.numBluRay.value = moviedata[0].numBluRay;				
					document.movie.numBluRayOut.value = moviedata[0].numBluRayOut;				
					});		

					//document.getElementById('id_photo_frame').src = '../photos/' + cardata[0].photo;
					document.movie.btnSubmit.onclick = function() {
						btnAddEditMovieSubmitClick('cmd_movie_edit');
					}
				}		
			 else {
				document.movie.btnSubmit.onclick = function() {
					btnAddEditMovieSubmitClick('cmd_movie_add');
				}
			}
		}
			
	//assign event handlers to other components of the form
	/*Important note: the following is a common mistake ->
		document.car.btnExit.onclick = btnAddEditCarExitClick(); //this will invoke the function and
		assign the result to onlick instead of assigning the function to onlick!
	*/		
	document.car.btnExit.onclick = function() { //this is a correct way of doing the assignment
		btnAddEditMovieExitClick();
	}
	//another way of assigning functions to events but this does not work for IE9 and below

