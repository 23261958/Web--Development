<?php
/*-------------------------------------------------------------------------------------------------
@Module: view.php

@Author: 
@Date: 
--------------------------------------------------------------------------------------------------*/
require_once('config.php'); 

class View {
    //Class contructor: performs any initialization
    public function __construct() {        
    }
    
    //Class destructor: performs any deinitialiation       
    public function __destruct() {        
    }
    
    //Creates left navigation panel
    public function leftNavPanel() {
        print file_get_contents('html/left_nav.html');
    }
    
    //Shows the home page
    public function showHomepage() {
        print file_get_contents('html/home.html');
    }
    public function showJoinForm() {
        print file_get_contents('html/join_form.html');
    }
    
    //Creates the dropdown select box to select a movie   
    public function moviesDropdownLoad($movies) 
    {
        print "
        <div style='color: #0e5968; float:left;'>
            <div class='topnav'>
            <label for='movie'><b>Movies:</b></label><br>
            <select name='movie' id='id_movie' onchange='movieDropdownChanged();'>
                <option value='all'>Select all</option>
        ";
        //This loads the select box with movie ids and titles
        foreach ($movies as $movie) 
        {            
            print "<option value=".$movie['movie_id'].">".$movie['title']."</option>";
        }
        
        print "
            </select>
            </div>
        </div>
        ";
    }

    //Creates the dropdown select box to select an actor 
    public function actorDropdownLoad($actors) 
    {
        print "
        <div style='color: #0e5968; float:left;'>
            <div class='topnav'>
            <label for='actors'><b>Actors:</b></label><br>
            <select name='actors' id='id_actor' onchange='actorDropdownChanged();'>
                <option value='all'>Select all</option>
        ";
        //This loads the select box with actor ids and names
        foreach ($actors as $actor) 
        {            
            print "<option value=".$actor['actor_id'].">".$actor['actor_name']."</option>";
        }
        
        print "
            </select>
            </div>
        </div>
        ";
    }
    //Creates the dropdown select box to select an genre 
    public function genreDropdownLoad($genres) 
    {
        print "
        <div style='color: #0e5968; float:left;'>
            <div class='topnav'>
            <label for='genres'><b>Genres:</b></label><br>
            <select name='genres' id='id_genre' onchange='genreDropdownChanged();'>
                <option value='all'>Select all</option>
        ";
        foreach ($genres as $genre) 
        {            
            print "<option value=".$genre['genre_id'].">".$genre['genre_name']."</option>";
        }
        
        print "
            </select>
            </div>
        </div>
        ";
    }
//Creates the dropdown select box to select an director 
public function directorDropdownLoad($directors) 
{
    print "
    <div style='color: #0e5968; float:left;'>
        <div class='topnav'>
        <label for='directors'><b>Directors:</b></label><br>
        <select name='directors' id='id_director' onchange='directorDropdownChanged();'>
            <option value='all'>Select all</option>
    ";
    foreach ($directors as $director) 
    {            
        print "<option value=".$director['director_id'].">".$director['director_name']."</option>";
    }
    
    print "
        </select>
        </div>
    </div>
    ";
}

//Creates the dropdown select box to select an classification 
public function classificationDropdownLoad($classifications) 
{
    print "
    <div style='color: #0e5968; float:left;'>
        <div class='topnav'>
        <label for='classifications'><b>Classifications:</b></label><br>
        <select name='classifications' id='classifications' onchange='classificationDropdownChanged();'>
            <option value='all'>Select all</option>
    ";
    foreach ($classifications as $classification) 
    {            
        print "<option value=".$classification['classification'].">".$classification['classification']."</option>";
    }
    
    print "
        </select>
        </div>
    </div>
    ";
}

    /*Displays error message
    */
    public function showError($error) 
    {
        print "<h2 style='color: red'>Error: $error</h2>";
    }

    //Displays an array of movies. However there will only be one movie in the array.
    public function showMovie($movie_array) 
    {
        $id = $movie_array[0]['movie_id'];
        $title = $movie_array[0]['title'];
        print "<br><br>";
        print "<h3>".$title."</h3>";
        if (!empty($movie_array)) 
        {
            
            $this->printMovieInHtmlStart();
            foreach ($movie_array as $movie) 
            {
                print_r ($movie);
                print ('<br><br>');
                $this->printMovieInHtml($movie);
            }
            $this->printMovieInHtmlEnd();
        }
    }
    
    //Displays an array of movies associated with an actor.
    public function showActorMovie($actor_movie_array, $actor_name) 
    {
        print ("<br><br><br>");
        //print ($actor_name);
        //print_r ($actor_movie_array);
        print "<br><br>";
        if (!empty($actor_movie_array)) 
        {
            print_r ($actor_movie_array);
            print ('<h2>Movies with '.$actor_name.'</h2>');
            $this->printMovieInHtmlStart();
            foreach ($actor_movie_array as $actor_movie) 
            {
                $this->printMovieInHtml($actor_movie);
            }
            $this->printMovieInHtmlEnd();
        }
        else
        {
            //echo "yes";
            print ('<h2>No movies found with '.$actor_name.'</h2>');
        }
    }
    //Displays an array of movies associated with an genre.
    public function showGenreMovie($genre_movie_array, $genre_name) 
    {
        print ("<br><br><br>");
        //print ($genre_name);
        //print_r ($genre_movie_array);
        print "<br><br>";
        if (!empty($genre_movie_array)) 
        {
            print_r ($genre_movie_array);
            print ('<h2>Movies with '.$genre_name.'</h2>');
            $this->printMovieInHtmlStart();
            foreach ($genre_movie_array as $genre_movie) 
            {
                $this->printMovieInHtml($genre_movie);
            }
            $this->printMovieInHtmlEnd();
        }
        else
        {
            //echo "yes";
            print ('<h2>No movies found with '.$genre_name.'</h2>');
        }
    }
    //Displays an array of movies associated with an director.
    public function showDirectorMovie($director_movie_array, $director_name) 
    {
        print ("<br><br><br>");
        //print ($director_name);
        //print_r ($director_movie_array);
        print "<br><br>";
        if (!empty($director_movie_array)) 
        {
            print_r ($director_movie_array);
            print ('<h2>Movies with '.$director_name.'</h2>');
            $this->printMovieInHtmlStart();
            foreach ($director_movie_array as $director_movie) 
            {
                $this->printMovieInHtml($director_movie);
            }
            $this->printMovieInHtmlEnd();
        }
        else
        {
            //echo "yes";
            print ('<h2>No movies found with '.$director_name.'</h2>');
        }
    }
    //Displays an array of movies associated with an classfication.
    public function showClassificationMovie($classfication_movie_array, $classfication) 
    {
        print ("<br><br><br>");
        //print ($classfication);
        //print_r ($classfication_movie_array);
        print "<br><br>";
        if (!empty($classfication_movie_array)) 
        {
            print_r ($classfication_movie_array);
            print ('<h2>Movies with '.$classfication.'</h2>');
            $this->printMovieInHtmlStart();
            foreach ($classfication_movie_array as $classfication) 
            {
                $this->printMovieInHtml($classfication_movie);
            }
            $this->printMovieInHtmlEnd();
        }
        else
        {
            //echo "yes";
            print ('<h2>No movies found with '.$classfication.'</h2>');
        }
    }
    public function printMovieInHtmlStart() 
    {
        print "
        <table style='border: 1px solid red; border-collapse: collapse'>
            <caption>This is simply a few of the movie items output in html table format.</caption>
            <tr>
                <th style='border: 1px solid red'>Movie Id</th>
                <th style='border: 1px solid red'>Title</th>
                <th style='border: 1px solid red'>Tagline</th>
                <th style='border: 1px solid red'>Thumbpath</th>
                <th style='border: 1px solid red'>Year</th>
            </tr>
        ";
    }        
    
    public function printMovieInHtml($movie) 
    {        
        $movie_id = $movie['movie_id'];
        $title = $movie['title'];
        $tagline = $movie['tagline'];
        $plot = $movie['plot'];
        $thumbpath = $movie['thumbpath'];
        $star1 = $movie['star1'];
        $star2 = $movie['star2'];
        $star3 = $movie['star3'];
        $costar1 = $movie['costar1'];
        $costar2 = $movie['costar2'];
        $costar3 = $movie['costar2'];
        $director = $movie['director'];
        $studio = $movie['studio'];
        $genre = $movie['genre'];
        $classification = $movie['classification'];
        $rental_period = $movie['rental_period'];
        $year = $movie['year'];
        $DVD_rental_price = $movie['DVD_rental_price'];
        $DVD_purchase_price = $movie['DVD_purchase_price'];
        $numDVD = $movie['numDVD'];
        $numDVDout = $movie['numDVDout'];
        $BluRay_rental_price = $movie['BluRay_rental_price'];
        $BluRay_purchase_price = $movie['BluRay_purchase_price'];
        $numBluRay = $movie['numBluRay'];
        $numBluRayOut = $movie['numBluRayOut'];

        print "
            <tr>
                <td style='border: 1px solid red'>$movie_id</td>
                <td style='border: 1px solid red'>$title</td>
                <td style='border: 1px solid red'>$tagline</td>
                <td style='border: 1px solid red'>$thumbpath</td>
                <td style='border: 1px solid red'>$year</td>
            </tr>
        ";
    }
    
    public function printmovieInHtmlEnd() 
    {        
        print "</table>";
    }
}

?>