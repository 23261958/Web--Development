/*-------------------------------------------------------------------------------------------------
@Module: template.js

@Author: 
@Date: 
--------------------------------------------------------------------------------------------------*/

//global variable if we are in editing mode. (Not used in this app) 
var editing_mode; 

//Use the onload event to load the default page
window.addEventListener("load", function() 
{
    makeAjaxGetRequest('main.php','cmd_load_homepage', null, updateContent);
    makeAjaxGetRequest('main.php','cmd_show_random_movies', null, updateLeftNavbar);

    editing_mode = false; //default when loaded
});

//Updates the content area if successful
function updateContent(data) 
{
    document.getElementById('id_content').innerHTML = data;
}
function updateLeftNavbar(data) 
{
    document.getElementById('id_left').innerHTML = data;
}
function loadLeftMoviezoneNavbar() 
{
    makeAjaxGetRequest('main.php','cmd_load_left_navbar_moviezone', null, updateLeftNavbar);
}
//Updates the top navigation panel in the content area
function updateTopNav(data=null) 
{
    var topnav = document.getElementById('id_topnav');
    if (data != null) 
    {
        topnav.innerHTML = data;
        topnav.style.display = "inherit";
    } 
    else 
    {
        topnav.innerHTML = '';
        topnav.style.display = "none";        
    }
}
// function pageBtnClick(page)
// {
//     var params = '';
//     param += '&page_name='+ page;
//     if (page == "html/moviezone.html")
//     {
//         makeAjaxGetRequest('main.php','cmd_load_new_release_movies', null, updateContent);
//         makeAjaxGetRequest('main.php','cmd_load_left_navbar_moviezone', null, updateLeftNavbar);
//     }
//  }
 function moviezoneClick() 
 {
     makeAjaxGetRequest('main.php','cmd_load_moviezonepage', null, function(data) 
     {        
        updateContent(data); //loads the home page to the content area
     });    
     makeAjaxGetRequest('main.php','cmd_load_new_release_movies', null, function(data) 
     {        
         updateContent(data); //loads the home page to the content area
     });    
     
     makeAjaxGetRequest('main.php','cmd_load_left_navbar_moviezone', null, function(data) 
    {
        updateLeftNavbar(data);

    });
    
 }
function newReleaseClick() 
{
    makeAjaxGetRequest('main.php','cmd_load_new_release_movies', null, function(data) 
    {   
        updateTopNav(); //resets and hides the search box         
        updateContent(data); //loads the home page to the content area
    });
    
       
}
function allmoviesClick() 
{
    makeAjaxGetRequest('main.php','cmd_load_all_movies', null, function(data) 
    {   
        updateTopNav(); //resets and hides the search box         
        updateContent(data); //loads the home page to the content area
    });
    
       
}

/* //Loads the home page into the content area.
function homePageClick() 
{
    makeAjaxGetRequest('main.php','cmd_load_homepage', null, function(data) 
    {        
        updateTopNav(); //resets and hides the search box    
        updateContent(data); //loads the home page to the content area
    });        
} */

//Loads the home page into the content area.
function homePageClick() 
{
    makeAjaxGetRequest('main.php', 'cmd_load_homepage', null, function(data) 
    {
        updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the Upload Student List form to the content area
    }); 
    
/*     makeAjaxGetRequest('main.php','cmd_show_random_movies', null, function(data) 
    {
        updateLeftNavbar(data);
    });  */        
}

function techzoneClick() 
{
    makeAjaxGetRequest('main.php', 'cmd_load_techzone', null, function(data) 
 {
    updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the Upload Student List form to the content area
    }); 
    makeAjaxGetRequest('main.php','cmd_show_random_movies', null, function(data) 
    {
        updateLeftNavbar(data);

    });         
}
         

//Loads the contact page into the content area.
function contactPageClick() 
{
    makeAjaxGetRequest('main.php', 'cmd_load_contactpage', null, function(data) 
 {
    updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the Upload Student List form to the content area
    }); 
    makeAjaxGetRequest('main.php','cmd_show_random_movies', null, function(data) 
    {
        updateLeftNavbar(data);

    });        
}
         

//Loads the selectct a movie content into the main content area.
function selectMovieBtnClick() 
{
    makeAjaxGetRequest('main.php', 'cmd_show_movies_dropdown', null, function(data) 
    {        
        updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the Upload Student List form to the content area
    });        
}


function searchByActorBtnClick() 
{
    //alert ("searchByActorBtnClick");
    makeAjaxGetRequest('main.php', 'cmd_search_by_actor_dropdown', null, function(data) 
    {        
        updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the Upload Student List form to the content area
    });        
}
function searchByDirectorBtnClick() 
{
    //alert ("searchByDirectorBtnClick");
    makeAjaxGetRequest('main.php', 'cmd_search_by_director_dropdown', null, function(data) 
    {        
        updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the Upload Student List form to the content area
    });        
}
function searchByStudioBtnClick() 
{
    //alert ("searchByDirectorBtnClick");
    makeAjaxGetRequest('main.php', 'cmd_search_by_studio_dropdown', null, function(data) 
    {        
        updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the Upload Student List form to the content area
    });        
}
function searchByGenreBtnClick() 
{
    //alert ("searchByGenreBtnClick");
    makeAjaxGetRequest('main.php', 'cmd_search_by_genre_dropdown', null, function(data) 
    {        
        updateTopNav(); //reset and hide the search box    
        updateContent(data); 
    });        
}
function searchByClassificationBtnClick() 
{
    //alert ("searchByClassificationBtnClick");
    makeAjaxGetRequest('main.php', 'cmd_search_by_classification_dropdown', null, function(data) 
    {        
        updateTopNav(); //reset and hide the search box    
        updateContent(data);  
    });        
}
function joinBtnClick() 
{
    //alert ("joinBtnClick");
    makeAjaxGetRequest('main.php', 'cmd_show_join_form', null, function(data) 
    {        
        updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the join form
    });  
    makeAjaxGetRequest('main.php','cmd_show_random_movies', null, function(data) 
    {
        updateLeftNavbar(data);

    });        
}

//exit to the main app
function exitClick() 
{
    if (editing_mode)
    {
        if (confirm("Data is not saved. Are you sure you want to exit?") == false)
        {
            return;  
        }
    }
    //Logs out the user
    makeAjaxGetRequest('main.php','cmd_logout', null, function(data) 
    {
        if (data == '_OK_') 
        {
            editing_mode = false;
            window.location.replace('index.php');
        }        
    });    
}

//Handles the onchange event when an item in the dropdown box is selected
function movieDropdownChanged() 
{
    var movie_id = document.getElementById('id_movie').value;
    var params = '';
    if (movie_id != 'all')
    {
        params += '&movie_id=' + movie_id;
    }
    makeAjaxGetRequest('main.php', 'cmd_movie_dropdown_select', params, updateContent);
}

//Handles the onchange event when an item in the dropdown box is selected
function actorDropdownChanged() 
{
    var actor = document.getElementById('id_actor');
    var actor_id = actor.options[actor.selectedIndex].value;
    var actor_name = actor.options[actor.selectedIndex].text;
    var params = '';
    if (actor_id != 'all')
    {
        params += '&actor_id=' + actor_id;
        params += '&actor_name=' + actor_name;
    }
    //alert (params);
    makeAjaxGetRequest('main.php', 'cmd_search_by_actor_dropdown_select', params, updateContent);
}
function genreDropdownChanged() 
{
    var genre = document.getElementById('id_genre');
    var genre_id = genre.options[genre.selectedIndex].value;
    var genre_name = genre.options[genre.selectedIndex].text;
    var params = '';
    if (genre_id != 'all')
    {
        params += '&genre_id=' + genre_id;
        params += '&genre_name=' + genre_name;
    }
    //alert (params);
    makeAjaxGetRequest('main.php', 'cmd_search_by_genre_dropdown_select', params, updateContent);
}
function directorDropdownChanged() 
{
    var director = document.getElementById('id_director');
    var director_id = director.options[director.selectedIndex].value;
    var director_name = director.options[director.selectedIndex].text;
    var params = '';
    if (director_id != 'all')
    {
        params += '&director_id=' + director_id;
        params += '&director_name=' + director_name;
    }
    //alert (params);
    makeAjaxGetRequest('main.php', 'cmd_search_by_director_dropdown_select', params, updateContent);
}
function studioDropdownChanged() 
{
    var studio = document.getElementById('id_studio');
    var studio_id = studio.options[studio.selectedIndex].value;
    var studio_name = studio.options[studio.selectedIndex].text;
    var params = '';
    if (studio_id != 'all')
    {
        params += '&studio_id=' + studio_id;
        params += '&studio_name=' + studio_name;
    }
    //alert (params);
    makeAjaxGetRequest('main.php', 'cmd_search_by_studio_dropdown_select', params, updateContent);
}
function classificationDropdownChanged() 
{
    var classification = document.getElementById('classifications');
    var classification = classification.options[classification.selectedIndex].text;
    var params = '';
    if (classification != 'all')
    {
        params += '&classification=' + classsification;
    }
    //alert (params);
    makeAjaxGetRequest('main.php', 'cmd_search_by_classification_dropdown_select', params, updateContent);
}
/* Write member to database
*/
function addNewMemberToDatabase(memberData)
{
    alert('template.js - about to call ajax post');
    makeAjaxPostRequest('main.php','cmd_add_member', memberData, function(data) 
    {
        if (data == '_OK_')
        {
            alert('Member has been added to database.');
            document.newMember.reset();  //reset form
        }
        else
        {
            alert(data);
            updateFormFeedback(data);
            document.newMember.username.select();
            document.getElementById('id_main_column').innerHTML = "JS error - data value is  " + data;
        }
    });   
}
