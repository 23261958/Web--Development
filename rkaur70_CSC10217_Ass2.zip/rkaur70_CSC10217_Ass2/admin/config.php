<?php
/*-------------------------------------------------------------------------------------------------
@Module: config.php
This server-side module defines all required settings and dependencies for the application

@Author: 
@Date: 
-------------------------------------------------------------------------------------------------*/

    //define all required messages and commands for the session checking purpose
    //request and login/logout commands
    define ('CMD_REQUEST','request'); //the key to access submitted command via POST or GET
    define ('CMD_LOGIN', 'cmd_login');
    define ('CMD_LOGOUT', 'cmd_logout');
    define ('CMD_MEMBER_LOGIN', 'cmd_member_login');
    define ('CMD_MEMBER_LOGOUT', 'cmd_member_logout');
    
    //error messages    
    define ('ERR_SUCCESS', '_OK_'); //no error, command is successfully executed
    define ('ERR_AUTHENTICATION', "Wrong username or password");
    
    //Perform session checking, if already logged in then just put user through.
    //Otherwise, show the login dialog box
    $php_version = phpversion();
    if (floatval($php_version) >= 5.4) 
    {    
        //need the session to start
        if (session_status() == PHP_SESSION_NONE) 
        {
            session_start();
        }
    } 
    else 
    {
        if (session_id() == '') 
        {
            session_start();
        }
    }

    /*We use 'authorised' as a keyword to identify if the user has not logged in
      if the keyword has not been set, check if this is the login session then continue
      if not simply terminate (a good security practice is to check for eligibility 
      before executing any php code)
    */
/*     if (empty($_SESSION['authorised'])) 
    {
        //no authorisation so check if user is trying to log in        
        if (empty($_REQUEST[CMD_REQUEST])||($_REQUEST[CMD_REQUEST] != CMD_LOGIN)) 
        { 
            //if no request or request is not a login request
            header("Location: login.php");
            //die();
        } 
    } */
    /* ... continue the execution otherwise ... 
    (this is a good security practice to check for the eligibility before executing any code)
    */
    
    //This is a good practice to define all constants which may be used at different places
    //define ('DB_CONNECTION_STRING', "mysql:host=localhost;dbname=db");
    //Replace the XXXXXXXXXXXX with database name user name and password etc.
    define ('DB_CONNECTION_STRING', "mysql:host=localhost;dbname=rkaur70_moviezone_db");
    define ('DB_USER', "rkaur70");
    define ('DB_PASS', "23261958");
    define ('MSG_ERR_CONNECTION', "Open connection to the database first");
    

    define ('MAX_RANDOM_MOVIES', 2 );
    // the folder where the movie images are stored
    define ('_SMALL_THUMB_MOVIE_POSTER_FOLDER_', "images/small_thumb_pics/");
    define ('_MOVIE_POSTER_FOLDER_', "images/small_pics/");
    
    //user request commands
    define ('CMD_SHOW_MOVIES_DROPDOWN', 'cmd_show_movies_dropdown'); //create and show movies dropdown
    define ('CMD_MOVIE_SELECT_ALL', 'cmd_movie_select_all');
    define ('CMD_MOVIE_DROPDOWN_SELECT', 'cmd_movie_dropdown_select'); //get MOVIE by submitted parameters
    define ('CMD_MOVIE_NEW_RELEASE_MOVIES', 'cmd_load_new_release_movies');
    define ('CMD_LOAD_HOMEPAGE', 'cmd_load_homepage');
    define ('CMD_LOAD_MOVIEZONEPAGE', 'cmd_load_moviezonepage');  
    define ('CMD_LOAD_CONTACTPAGE', 'cmd_load_contactpage');  
    define ('CMD_SEARCH_BY_ACTOR_DROPDOWN', 'cmd_search_by_actor_dropdown'); 
    define ('CMD_SEARCH_BY_ACTOR_DROPDOWN_SELECT', 'cmd_search_by_actor_dropdown_select');
    define ('CMD_SEARCH_BY_GENRE_DROPDOWN', 'cmd_search_by_genre_dropdown'); 
    define ('CMD_SEARCH_BY_GENRE_DROPDOWN_SELECT', 'cmd_search_by_genre_dropdown_select');  
    define ('CMD_SEARCH_BY_DIRECTOR_DROPDOWN', 'cmd_search_by_director_dropdown'); 
    define ('CMD_SEARCH_BY_DIRECTOR_DROPDOWN_SELECT', 'cmd_search_by_director_dropdown_select');
    define ('CMD_SEARCH_BY_CLASSIFICATION_DROPDOWN', 'cmd_search_by_classification_dropdown'); 
    define ('CMD_SEARCH_BY_CLASSIFICATION_DROPDOWN_SELECT', 'cmd_search_by_classification_dropdown_select');  
    define ('CMD_SHOW_JOIN_FORM', 'cmd_show_join_form'); 
    define ('CMD_SHOW_ADD_FORM', 'cmd_show_add_form'); 
    define ('CMD_ADD_MEMBER', 'cmd_add_member'); 
    define ('CMD_SHOW_RANDOM_MOVIES', 'cmd_show_random_movies');
    define ('CMD_LOAD_LEFT_NAVBAR_MOVIEZONE', 'cmd_load_left_navbar_moviezone');
    define ('CMD_SHOW_MEMBER_DROPDOWN', 'cmd_show_member_dropdown'); //create and show movies dropdown
    define ('CMD_MEMBER_DROPDOWN_SELECT', 'cmd_member_dropdown_select'); //get MOVIE by submitted parameters


    
    //this was missing and has been added here
    define ('CMD_SHOW_MOVIE_ADD_FORM', 'cmd_show_movie_add_form');
    define ('CMD_SHOW_MOVIE_EDIT_FORM', 'cmd_show_movie_edit_form');
    define ('CMD_SHOW_MEMBER_EDIT_FORM', 'cmd_show_member_edit_form');

    
    
    define ('ERR_NO_MOVIES', "No movies found for ");
    define ('errAdminRequired', "Login as admin to perform this task");

    //load the application modules
    require_once('dba.php');
    require_once('model.php');
    require_once('view.php');
    require_once('controller.php');
?>