/*Use onload event to load the page with random cars
*/

var editing_mode; 
window.addEventListener("load", function() 
{
    makeAjaxGetRequest('main.php','cmd_load_homepage', null, updateContent);
	editing_mode = false; //default when loaded
});

function updateContent(data) {
	document.getElementById('id_content').innerHTML = data;
}

function updateTopNav(data=null) 
{
    var topnav = document.getElementById('id_topnav');
    if (data != null) 
    {
        topnav.innerHTML = data;
        topnav.style.display = "inherit";
    } 
    else 
    {
        topnav.innerHTML = '';
        topnav.style.display = "none";        
    }
}

/*Updates the top navigation panel
*/
function updateTopNav (data=null) {
	var topnav = document.getElementById('id_topnav');
	if (data != null) {
		topnav.innerHTML = data;
		topnav.style.display = "inherit";
	} else {
		topnav.innerHTML = '';
		topnav.style.display = "none";		
	}
}


//submit car data to server
function btnAddEditMovieSubmitClick(command) {
	if (!validate(document.movie))
		return;
	var moviedata = new FormData(document.movie);
	makeAjaxPostRequest('main.php', command, moviedata, function(data) {
		if (data == '_OK_') {
			if (command == 'cmd_movie_add') {
				alert('The car data has been successfully updated to the database');
				document.movie.reset(); //reset form
				document.getElementById('id_error').innerHTML = '';
			} else {
				btnAddEditMovieExitClick();
			}
		} else {
			document.getElementById('id_error').innerHTML = data;
		}
	});
}

//exit add/edit mode and return to browsing mode
function btnAddEditMovieExitClick() {
	makeAjaxGetRequest('admin_main.php', null, function(data) {
		updateContent(data);
		//show the top navigation panel
		makeAjaxGetRequest('admin_main.php', null, function(data) {
			editing_mode = false;
		});
	});	
}


//shows car add/edit form
function addMovieClick() {
		makeAjaxGetRequest('main.php','cmd_show_movie_add_form', null, function(data) {		
			updateContent(data); //load the add/edit form to the content area
			updateTopNav(); //reset and hide the search box    
		});		
	}



//sends request to server to display delete car UI
// function deleteMovieClick() {
// 	makeAjaxGetRequest('main.php', 'cmd_show_movies_dropdown', null, function(data) {
// 	// if (!editing_mode) {
// 	// 	//makeAjaxGetRequest('main.php', 'cmd_show_movies_dropdown', null, function(data){
// 	// 	if (confirm("Are you sure to delete selected movies?") == true) {
// 	// 		makeAjaxGetRequest('main.php','cmd_movie_delete', null, function(data){
// 	// 			if (data == '_OK_') {
// 	// 				makeAjaxGetRequest('main.php','cmd_movie_select_all', null, updateContent);
// 	// 			} else {
// 	// 				updateContent(data);
// 	// 			}
// 	// 		});
// 	// 	}
// 	//}
// 	updateContent(data); //load the add/edit form to the content area
// 			updateTopNav(); //reset and hide the search box  

// 	});
// }
function selectMovieBtnClick() 
{
    makeAjaxGetRequest('main.php', 'cmd_show_movies_dropdown', null, function(data) 
    {        
        updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the Upload Student List form to the content area
    });        
}
function movieDropdownChanged() 
{
    var movie_id = document.getElementById('id_movie').value;
    var params = '';
    if (movie_id != 'all')
    {
        params += '&movie_id=' + movie_id;
    }
	makeAjaxGetRequest('main.php', 'cmd_show_movie_edit_form', params, updateContent);
	
}
function selectMemberBtnClick() 
{
    makeAjaxGetRequest('main.php', 'cmd_show_member_dropdown', null, function(data) 
    {        
        updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the Upload Student List form to the content area
    });        
}
function memberDropdownChanged() 
{
    var member_id = document.getElementById('id_member').value;
    var params = '';
    if (member_id != 'all')
    {
        params += '&member_id=' + member_id;
    }
	makeAjaxGetRequest('main.php', 'cmd_show_member_edit_form', params, updateContent);
	
}


function joinBtnClick() 
{
    //alert ("joinBtnClick");
    makeAjaxGetRequest('main.php', 'cmd_show_join_form', null, function(data) 
    {        
        updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the join form
	}); 
} 
		  

function exitClick() 
{
    if (editing_mode)
    {
        if (confirm("Data is not saved. Are you sure you want to exit?") == false)
        {
            return;  
        }
    }
    //Logs out the user
    makeAjaxGetRequest('main.php','cmd_logout', null, function(data) 
    {
        if (data == '_OK_') 
        {
            editing_mode = false;
            window.location.replace('../index.php');
        }        
    });    
}
//handles the car checkbox click event to sends request to server to check/uncheck car
function movieCheckClick(check) {		
	var params = '&movie_id=' + check.value;
	makeAjaxGetRequest('main.php','cmd_movie_check', params, function(data) {
		if (data == '_OK_') {		
			check.checked = true;
		} else
			check.checked = false;
	});
	event.stopPropagation(); //so edit event does not fire.
}




/*Gets the state list from server and create the options on the fly
*/
function updateMovieForm(movie_id) {
	

			if (movie_id != null) { //update car mode
				//update the form with car data
				var params = '&movie_id=' + movie_id;
				makeAjaxGetRequest('admin_main.php', params, 
				function(data) {
					var moviedata = JSON.parse(data);
					document.movie.title.value = moviedata[0].title;
					document.movie.year.value = moviedata[0].year;
					document.movie.tagline.value = moviedata[0].tagline;
					document.movie.plot.value = moviedata[0].plot;
					document.movie.director_name.value = moviedata[0].director_name;
					document.movie.studio_name.value = moviedata[0].studio_name;
					document.movie.genre_name.value = moviedata[0].genre_name;
					document.movie.star1.value = moviedata[0].star1;	
					document.movie.star2.value = moviedata[0].star2;				
					document.movie.star3.value = moviedata[0].star3;				
					document.movie.costar1.value = moviedata[0].costar1;				
					document.movie.costar2.value = moviedata[0].costar2;				
					document.movie.costar3.value = moviedata[0].costar3;		
					document.movie.costar3.value = moviedata[0].costar3;				
					document.movie.rental_period.value = moviedata[0].rental_period;				
					document.movie.DVD_rental_price.value = moviedata[0].DVD_rental_price;				
					document.movie.DVD_purchase_price.value = moviedata[0].DVD_purchase_price;	
					document.movie.numDVD.value = moviedata[0].numDVD;				
					document.movie.numDVDout.value = moviedata[0].numDVDout;				
					document.movie.numDVDout.value = moviedata[0].numDVDout;				
					document.movie.BlueRay_rental_price.value = moviedata[0].BlueRay_rental_price;				
					document.movie.BluRay_purchase_price.value = moviedata[0].BluRay_purchase_price;			
					document.movie.numBluRay.value = moviedata[0].numBluRay;				
					document.movie.numBluRayOut.value = moviedata[0].numBluRayOut;				
	
			
		
			
					
								});		

			

					//document.getElementById('id_photo_frame').src = '../photos/' + cardata[0].photo;
					document.movie.btnSubmit.onclick = function() {
						btnAddEditMovieSubmitClick('cmd_movie_edit');
					}
				}		
			 else {
				document.movie.btnSubmit.onclick = function() {
					btnAddEditMovieSubmitClick('cmd_movie_add');
				}
			}
		}
			
		
	
	//assign event handlers to other components of the form
	/*Important note: the following is a common mistake ->
		document.car.btnExit.onclick = btnAddEditCarExitClick(); //this will invoke the function and
		assign the result to onlick instead of assigning the function to onlick!
	*/		
	document.movie.btnExit.onclick = function() { //this is a correct way of doing the assignment
		btnAddEditMovieExitClick();
	}
	
	function addNewMemberToDatabase(memberData)
{
    alert('admin.js - about to call ajax post');
    makeAjaxPostRequest('main.php','cmd_add_member', memberData, function(data) 
    {
        if (data == '_OK_')
        {
            alert('Member has been added to database.');
            document.newMember.reset();  //reset form
        }
        else
        {
            alert(data);
            updateFormFeedback(data);
            document.newMember.username.select();
            document.getElementById('id_main_column').innerHTML = "JS error - data value is  " + data;
        }
    });   
}

//Loads the home page into the content area.
function homePageClick() 
{
    makeAjaxGetRequest('main.php', 'cmd_load_homepage', null, function(data) 
    {
        updateTopNav(); //reset and hide the search box    
        updateContent(data); //load the Upload Student List form to the content area
    });         
}