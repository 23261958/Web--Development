<?php
/*-------------------------------------------------------------------------------------------------
@Module: index.php

@Author: 
@Date: 
-------------------------------------------------------------------------------------------------*/
require_once('main.php');
?>
<html>
<head>
    <title>MVC Template</title>
    <link rel="stylesheet" type="text/css" href="css/template_styles.css">
    <link rel="stylesheet" type="text/css" href="css/form_styles.css">
    <link rel="stylesheet" type="text/css" href="css/moviezone.css">
    <script src="js/ajax.js"></script>
    <script src="js/template.js"></script>
    <script src="js/new_member_validate.js"></script>
</head>

<body>
    <div id="id_container">
        <header>
            <h1>DVD Emporium</h1>
            <h2>
            <?php 
                if(isset($_SESSION['member_authorised']))
                {
                    echo "(Logged on as Member: ".$_SESSION['member_authorised'].")";
                }
                
                if(isset($_SESSION['authorised']))
                {                    
                    echo "(Logged on as Administrator: ".$_SESSION['authorised'].")";
                }
            ?>
            </h2>
            <?php include_once('html/h_navbar.html'); ?>
        </header>
        <!-- left navigation area -->
        <div id="id_left">
            <!-- load the navigation panel by embedding php code -->
            <?php $controller->handleLoadLeftMoviezoneNavbarRequest()?>
        </div>
        <!-- right area -->    
        <div id="id_right">
            <!-- top navigation area -->
            <div id="id_topnav">            
                <!-- the top navigation panel is loaded on demand using Ajax (see js code) -->
            </div>
            <!-- main content area -->
            <div id="id_content"></div>
        </div>
        <!-- footer area -->
        <footer>  <div id="footer"> I am the copyright holder of content of this site &copy;rkaur70
		 <a href= "http://infotech.scu.edu.au/~rkaur70" target="http://infotech.scu.edu.au/~rkaur70">
			http://infotech.scu.edu.au/~rkaur70</a>    </div> </footer>
</body>
</html>